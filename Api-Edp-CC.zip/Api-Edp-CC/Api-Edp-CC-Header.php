<?php
header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Origin: http://localhost:8100');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, X-PINGOTHER , Content-Range, Content-Disposition, Content-Description');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Max-Age: 5000');
header('Connection: Keep-Alive');


?>
    
    
    